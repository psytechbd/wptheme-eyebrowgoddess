<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package EyebrowGoddess
 */

?>
<div class="container footer">
	<div class="row">
		<div class="col-md-6">
		Result may very from person*
		</div>
		<div class="col-md-6 text-right">
		Privacy | Cokies | Terms Of Service

		</div>
	</div>
	<div class="row">
		<div class="col-md-12 tag">
			<p>
			Privacy Policy | Disclaimer
<br>
Microblading kent, microblading canterbury, microblading price, microblading eyebrow specialist, microblading maidstone, microblading price list, best microblading, get microblading eyebrows, microblading best, microblading top specialist, eyebrow goddess microblading, Microblading brows, get microblading brows -
	
			</p>
		</div>
	</div>
</div>
</div><!-- #page -->

<?php wp_footer(); ?>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>
</html>
